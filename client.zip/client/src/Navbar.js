// import React from "react";
// import { Link } from "react-router-dom";
// import { FaEthereum } from "react-icons/fa";
// // import { Vortex } from "react-loader-spinner";
// const Navbar = () => {
//   return (
//     <div className="navbar">
//       <h1>CryptoMaina</h1>
//       <ul>
//         <li>
//           <Link to="/">Home</Link>
//         </li>
//         <li>
//           <Link to="/Coins">Coins</Link>
//         </li>
//       </ul>
//     </div>
//   );
// };

// export default Navbar;
