import { useEffect, useState } from "react";
import { ethers } from "ethers";
import KECCAK256 from "keccak256";
import MerkleTree from "merkletreejs";
import { Buffer } from "buffer/";
import "./App.css";
// import Navbar from "./Navbar";
import artifact from "./artifacts/contracts/MerkleDistributor.sol/MerkleDistributor.json";
const CONTRACT_ADDRESS = "0x0d95B221377ce96397c2fa399ba0C966DB8841B0";

window.Buffer = window.Buffer || Buffer;

function App() {
  const [provider, setProvider] = useState(undefined);
  const [signer, setSigner] = useState(undefined);
  const [contract, setContract] = useState(undefined);
  const [signerAddress, setSignerAddress] = useState(undefined);
  const [tree, setTree] = useState(undefined);
  const [proof, setProof] = useState([]);
  const [claimStatus, setClaimStatus] = useState("");

  useEffect(() => {
    const onLoad = async () => {
      if (window.ethereum) {
        const provider = await new ethers.BrowserProvider(window.ethereum);
        setProvider(provider);
        const contract = await new ethers.Contract(
          CONTRACT_ADDRESS,
          artifact.abi,
          provider
        );
        setContract(contract);
        const tree = await getTree();
        setTree(tree);
      } else {
        console.error("error");
      }
    };
    onLoad();
  }, []);

  const isConnected = () => signer !== undefined;
  const connect = () => {
    getSigner(provider).then((signer) => {
      setSigner(signer);
    });
  };

  const getTree = async () => {
    const indexedAddresses = require("./walletAddresses.json");
    const addresses = [];
    Object.keys(indexedAddresses).forEach(function (idx) {
      addresses.push(indexedAddresses[idx]);
    });
    const leaves = addresses.map((x) => KECCAK256(x));
    const tree = new MerkleTree(leaves, KECCAK256, { sortPairs: true });
    return tree;
  };

  const getSigner = async (provider) => {
    const signer = await provider.getSigner();
    const address = await signer.getAddress();
    setSignerAddress(address);
    const proof = tree.getHexProof(KECCAK256(address));
    setProof(proof);
    return signer;
  };

  const claimAirdrop = async () => {
    try {
      await contract.connect(signer).claim(proof);
      setClaimStatus("Airdrop claimed successfully");
    } catch (error) {
      if (error.message.includes(" Drop already claimed")) {
        setClaimStatus("Airdrop has already been claimed");
      } else if (error.message.includes("User denied transaction")) {
        setClaimStatus("Transection Denide");
        console.log("Transaction was rejected by the user");
      } else if (error.message.includes("Invalid proof")) {
        setClaimStatus("Sorry you are not eligible");
      } else {
        console.error("Error claiming airdrop:", error.message);
        setClaimStatus("Error claiming airdrop");
      }
    }
  };

  return (
    <>
      {/* <Navbar /> */}
      <div className="App">
        <header className="App-header">
          {isConnected() ? (
            <div>
              <p> Hii {signerAddress?.substring()}</p>
              <div className="list-group">
                <div className="list-group-item">
                  <button
                    className="btn btn-success"
                    onClick={() => claimAirdrop()}
                  >
                    Claim Your Airdrop
                  </button>
                </div>
                {claimStatus && (
                  <div className="list-group-item">
                    <p>{claimStatus}</p>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div>
              <p>You are not connected</p>
              <button onClick={connect} className="btn btn-primary">
                Connect Metamask
              </button>
            </div>
          )}
        </header>
      </div>
    </>
  );
}

export default App;
